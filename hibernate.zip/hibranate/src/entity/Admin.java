package entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Admin {
	@Id
	private int adminId;
	private String adminUserName;
	private String adminPassword;
	public Admin() {
		
	}
	
	public Admin(int adminInt, String adminUserName, String adminPassword) {
		super();
		this.adminId = adminInt;
		this.adminUserName = adminUserName;
		this.adminPassword = adminPassword;
	}
	public int getAdminInt() {
		return adminId;
	}
	public void setAdminInt(int adminInt) {
		this.adminId = adminInt;
	}
	public String getAdminUserName() {
		return adminUserName;
	}
	public void setAdminUserName(String adminUserName) {
		this.adminUserName = adminUserName;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	
	

}
