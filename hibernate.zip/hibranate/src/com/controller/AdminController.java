package com.controller;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Admin;

public class AdminController {

	public static void main(String[] args) throws Exception, RollbackException, HeuristicMixedException, HeuristicRollbackException, SystemException {
		//step1
		Configuration cfg = new Configuration();
		
		
		//2
		cfg.configure("hibernate.cfg.xml").addAnnotatedClass(Admin.class);
		
		
		//3
		SessionFactory sf=cfg.buildSessionFactory();
		
		
		//4
		Session ses =sf.openSession();
		
		
		//5
		Transaction tr=(Transaction) ses.beginTransaction();
		Admin am=new Admin();
		am.setAdminInt(101);
		am.setAdminUserName("Namrata");
		am.setAdminPassword("nam123");
		
		ses.save(am);
		
		tr.commit();
		ses.close();
		
	

	}

}
