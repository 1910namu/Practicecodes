package com.Dao;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;

import com.cfg.jdbc.JdbcConnection1;

public class UserDao {
	
	public String createTable(String tableName)throws SQLException {
		
		String query = "create table "+ tableName+
				"(userId int primary key ," 
				+ " userName varchar(50) ,"
				+ " userPass Varchar(20))";
		Connection con = JdbcConnection1.getcConnection(); 
	    Statement st =  con.createStatement();
		st.execute(query);
		return "table created";
	}
	
	public String insertUser(String tableName,int uID,String userName,String userPass) throws SQLException {
		String query = "insert into "+ tableName
				+" values("+ uID +",'"
				+ userName+ "','"
				+ userPass+ "')";
		Connection con = JdbcConnection1.getcConnection(); 
	    Statement st =  con.createStatement();
		st.execute(query);
		return" data inserted";
	}

}
