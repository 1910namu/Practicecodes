package com.Controller;

import java.sql.SQLException;

import com.service.UserService;

public class UserController {
	
	static UserService us = new UserService();
	
	public static void createTable(String tableName) {
		try {
			String msg = us.createTable(tableName);
			System.out.println(msg);
		} catch (SQLException e) {
			e.printStackTrace();
			
		}

	}
	
	public static void insertUser1(String tableName, int uID, String userName, String userPass) throws SQLException {
		
		String msg = us.insertUser1(tableName, uID, userName, userPass);
		System.out.println(msg);
		
	}
	public static void main(String[] args) throws SQLException {
		//createTable("User1");
		insertUser1("user1",11,"Namrata","namrata@19");
}
	

}
