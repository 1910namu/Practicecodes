package com.cfg.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcConnection1 {
	
	public static Connection getcConnection() {
		
		try {
			System.out.println("1");
		Class.forName("com.mysql.cj.jdbc.Driver");
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
			
		}
		System.out.println("2");
		
		String url = "jdbc:mysql://localhost:3306/JDBCex";
		String userName = "root";
		String password = "Sana@9022";
		
		Connection con = null;
		try {
			con = DriverManager.getConnection(url,userName,password);
			System.out.println("3");
		}catch(SQLException e) {
			e.printStackTrace();	
		}
		return con;	
	}
}
