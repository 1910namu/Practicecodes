package com.service;

import java.sql.SQLException;

import com.Dao.UserDao;

public class UserService {
	
	UserDao ud = new UserDao();

	
	public String createTable(String tableName)throws SQLException{
		
		String msg = null;
		if(tableName!= null) {
			msg = ud.createTable(tableName);
		}else {
			System.out.println("please enter valid name");
		}
		return msg;
	}
public String insertUser1(String tableName, int uID, String userName, String userPass)throws SQLException{

	return ud.insertUser(tableName, uID, userName, userPass);
	
}
}

