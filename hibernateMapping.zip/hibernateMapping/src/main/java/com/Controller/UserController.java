package com.Controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.Entity.Role;
import com.Entity.User;

public class UserController {

	public static void main(String[] args) {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		
		Transaction transaction= session.beginTransaction();
		
		Role admin = new Role();
		admin.setRoleId(1);
		admin.setRoleName("Admin");
		
		Role user = new Role();
		user.setRoleId(2);
		user.setRoleName("User");
		
		
		User ur1 = new User();
		ur1.setUserId(101);
		ur1.setUserName("Namrata");
		ur1.setUserPassword("nam@123");
		ur1.setRole(user);
		
		
		User ur2 = new User();
		ur2.setUserId(102);
		ur2.setUserName("Vaishnavi");
		ur2.setUserPassword("vai@18");
		ur2.setRole(user);

		
		session.save(admin);
		session.save(user);
		session.save(ur1);
		
		
		
		
		transaction.commit();
		session.close();
		factory.close();
	}

}
