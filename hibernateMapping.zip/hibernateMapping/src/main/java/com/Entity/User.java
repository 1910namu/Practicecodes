package com.Entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class User {
	
	@Id
	private  long userId;
	private String userName;
	private String userPassword;
	
	@OneToOne//to delete the column of user table;  (mappedBy = "User" , cascade = CascadeType.ALL)
	private Role role;
	
	public User() {
		
	}

	public User(long userId, String userName, String userPassword, Role role){
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPassword = userPassword;
		this.role = role;
	}


	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	
	

}
