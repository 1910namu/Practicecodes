package com.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import org.hibernate.query.Query;

import com.entity.User;

public class Userrepo {

	public String adduser(User am) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml").addAnnotatedClass(User.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tr = ses.beginTransaction();
		ses.save(am);
		tr.commit();
		ses.close();
		sf.close();
		return "user inserted ....!";

	}

	public User updateUser(long uId, String userName, String password) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml").addAnnotatedClass(User.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tr = ses.beginTransaction();
		User ur = new User();
		ur.setUserId(uId);
		ur.setUserName(userName);
		ur.setUserPassword(password);
		ses.update(ur);
		tr.commit();
		ses.close();
		sf.close();
		return ur;
	}

	public String updateUserById(Long uId, User ur) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml").addAnnotatedClass(User.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tr = ses.beginTransaction();

		if (uId == ur.getUserId()) {
			ses.update(ur);
		} else {
			System.out.println(uId + "this id user not found");
		}
		return "user updated....";
	}

	public String userDeleteById(long uId) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml").addAnnotatedClass(User.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tr = ses.beginTransaction();
		ses.delete(uId);
		tr.commit();
		ses.close();
		sf.close();
		return "User deleted by Id...";
		
		
	}

	public List<User> fetchUserList() {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml").addAnnotatedClass(User.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tr = ses.beginTransaction();
		Query<User> query = ses.createQuery("FROM User", User.class);
		List<User> userList = query.getResultList();
		tr.commit();
		ses.close();
		return userList;
		
	}
	
	public User getUserById(Long uId) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml").addAnnotatedClass(User.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		User user = ses.get(User.class, uId);
		ses.close();
		sf.close();
		return user;
		
	}

	


	
}
