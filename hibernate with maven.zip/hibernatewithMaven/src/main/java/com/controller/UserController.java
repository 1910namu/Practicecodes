package com.controller;

import com.entity.User;
import com.service.UserService;

public class UserController {

	//addUser
	static UserService service = new UserService();

	public void adduser(User am) {
		String msg = service.adduser(am);
		System.out.println(msg);
	}
	
	//Updateuser
	
	 public void updateUser(User am) {
		 String msg = service.updateUser(am);
		 System.out.println(msg);
		 
	 }
	
	//deleteuser
	
	 
	 public void userDeleteById(long am) {
		 String msg = service.userDeleteById(am);
		 System.out.println(msg);
	 }
	
	//get user by id
		
		 public void getUserById(User am) {
			 String msg = service.getUserById(am);
			 System.out.println(msg);
		 }
	
	//get user list

			 
			 public void fetchUserList(User am) {
				 String msg = service.fetchUserList(am);
				 System.out.println(msg);
				 
			 }
	public static void main(String[] args) {

		User ur1 = new User();
		ur1.setUserId(101);
		ur1.setUserName("Namrata");
		ur1.setUserPassword("nam123");
		UserController uc = new UserController();
		uc.adduser(ur1);
	}
}
