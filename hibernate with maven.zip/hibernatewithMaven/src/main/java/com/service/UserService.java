package com.service;

import com.entity.User;
import com.repository.Userrepo;

public class UserService {

	Userrepo repo = new Userrepo();

	public String adduser(User am) {

		String msg = null;
		if (am != null) {
			msg = repo.adduser(am);
		} else {
			System.out.println("please enter valid information..");
		}
		return msg;

	}

	public String updateUser(User am) {
		String msg = null;
		if(am!=null) {
			msg = repo.updateUser(101, msg, msg);
		}else {
			System.out.println("please enter valid information..");
		}
		return msg;
	}

	public String userDeleteById(long am) {
		String msg = null;
		if (am != null) {
			msg = repo.userDeleteById(am);
		} else {
			System.out.println("please enter valid information..");
		}
		return msg;
	}

	public String getUserById(User am) {
		String msg = null;
		if (am != null) {
			msg = repo.getUserById(am);
		} else {
			System.out.println("please enter valid information..");
		}
		return msg;
	}

	public String fetchUserList(User am) {
		String msg = null;
		if (am != null) {
			msg = repo.fetchUserList();
		} else {
			System.out.println("please enter valid information..");
		}
		return msg;
	}
}
